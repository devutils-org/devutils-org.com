# Devutils — exports réseaux sociaux

Rendu du véritable modèle 3D de src/scene.js et src/shapes.js, figé à son état initial. Fond opaque.

Chaque format existe avec « See beyond / the surface. » et en logo seul.

- linkedin-banner-with-phrase.png — 1584 × 396
- linkedin-banner-logo-only.png — 1584 × 396
- linkedin-post-with-phrase.png — 1200 × 627
- linkedin-post-logo-only.png — 1200 × 627
- github-social-preview-with-phrase.png — 1280 × 640
- github-social-preview-logo-only.png — 1280 × 640
- github-avatar-with-phrase.png — 800 × 800
- github-avatar-logo-only.png — 800 × 800
- social-square-with-phrase.png — 1080 × 1080
- social-square-logo-only.png — 1080 × 1080
- story-vertical-with-phrase.png — 1080 × 1920
- story-vertical-logo-only.png — 1080 × 1920

Ouvrir index.html pour parcourir les images. La version logo-only de github-avatar convient à une découpe circulaire. Les versions avec phrase servent surtout aux publications et aperçus.

## License

MIT or Apache-2.0, at your option. See LICENSE-MIT and LICENSE-APACHE.
