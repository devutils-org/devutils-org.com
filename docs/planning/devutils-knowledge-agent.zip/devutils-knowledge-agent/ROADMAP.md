# Implementation Roadmap — Agent Execution Plan

## Operating principles
Small, reviewable changes. **No rewrite**. Existing site must continue to work after each phase. Build a useful vertical slice before expanding taxonomy. Run baseline tests before making changes. If assumptions in these docs conflict with current code, document the discrepancy and adapt conservatively.

## Phase 0 — Repository audit and ADR
- [ ] Clone/open repository; inspect README, package scripts, Vite config, prerender pipeline, route registry, i18n, metadata, sitemap and deploy workflow.
- [ ] Run `npm install` or `npm ci` as appropriate, `npm test`, `npm run build`; record baseline failures separately.
- [ ] Identify safest integration point for generated Markdown routes; avoid one manually declared placeholder per article.
- [ ] Document `docs/adr/knowledge-v1.md`: decision, rejected alternatives, migration seams and open questions.

**Done when:** agent can describe how new pages become pre-rendered HTML and deployed under existing URLs without altering current pages.

## Phase 1 — Content contracts and ingestion
- [ ] Add Markdown parser/frontmatter support with minimal dependencies.
- [ ] Define schemas for concepts, events, figures, paths, labs and locale metadata.
- [ ] Validate IDs, slugs, status, source metadata, dates, relations and uniqueness.
- [ ] Implement deterministic route manifest and build-time backlinks.
- [ ] Add fixture content and tests for invalid metadata and missing references.

**Done when:** a malformed content entry fails the build with a helpful error; a valid entry generates stable metadata.

## Phase 2 — Static pages and navigation
- [ ] Integrate route generation into existing Vite/prerender pipeline.
- [ ] Create `/knowledge/`, `/knowledge/computing-stack/`, `/history/`, `/figures/`, `/learn/`, `/labs/`.
- [ ] Render a real concept, a figure and a historical event, with cross-links.
- [ ] Add breadcrumbs, side navigation, TOC, related content, source list and mobile reading layout.
- [ ] Match devutils design language without expensive per-page 3D effects.
- [ ] Ensure HTML content works with JavaScript disabled.

**Done when:** all new pages load directly on GitHub Pages, are linked from navigation, and can be crawled without client-side rendering.

## Phase 3 — SEO, locale and publishing integrity
- [ ] Integrate all published pages into sitemap and metadata pipeline.
- [ ] Add canonical URLs, Open Graph metadata, meaningful titles and descriptions.
- [ ] Establish explicit EN/FR fallback policy; test language switch and hreflang correctness.
- [ ] Implement internal link checker, redirects/aliases strategy and published/draft exclusion.
- [ ] Validate accessibility, responsive layout, reduced motion and no-JS reading.
- [ ] Verify existing tool landing pages, ATFQ book and deployment remain unchanged.

**Done when:** new and existing pages pass CI, canonical/sitemap checks, and basic mobile/performance inspection.

## Phase 4 — Search and history discovery
- [ ] Benchmark Pagefind or equivalent on generated pages; implement static search if appropriate.
- [ ] Build timeline from verified event records with category/date filters as progressive enhancement.
- [ ] Add figure directory filters and reciprocal links to concepts/events.
- [ ] Keep a usable non-JavaScript index and timeline fallback.

**Done when:** readers can discover articles by search, era, figure and related concept without requiring a backend.

## Phase 5 — Learning paths and labs
- [ ] Build paths as ordered references to canonical content.
- [ ] Add one small interactive lab (e.g. Boolean gate simulator) with accessible fallback.
- [ ] Document reproducibility, browser compatibility, performance budget and tests.
- [ ] Keep heavy dependencies off article routes.

**Done when:** at least one learning path and one working lab demonstrate the full authoring model.

## Phase 6 — Evaluate actual limits (not a mandatory rewrite)
Measure: build time, content count, search index size, first-load JS, rendering performance, authoring friction, translation maintenance and need for runtime state. Only consider a Rust CLI, Axum backend, Postgres, React islands or specialized graph DB if measurements and product features warrant them. Write a new ADR before migration.

## First PR suggested scope
Deliver Phases 0–2 minimally, with three representative linked entries and overview pages. Defer complex search, graph visualization, CMS and community features. The agent should not attempt to write the entire encyclopedia in one PR.

## Acceptance checklist
- [ ] Existing pages and routes unchanged.
- [ ] `npm test` passes (or pre-existing failures documented).
- [ ] `npm run build` passes and `dist/` includes article HTML.
- [ ] Direct navigation and refresh work on GitHub Pages URL paths.
- [ ] No-JS article reading works.
- [ ] New pages have correct SEO metadata and sitemap entries.
- [ ] EN/FR behavior is explicit and correct.
- [ ] Broken links, duplicate IDs and invalid relations fail CI.
- [ ] All historical claims in published sample entries are sourced.
- [ ] README documents authoring and build commands.
- [ ] No backend, React rewrite or unrequested hosting migration.

## Agent reporting format
At end of each phase report: files changed, behavior added, commands run and results, content published, compatibility concerns, deferred work and next recommended small PR. Never claim a feature is implemented without running the relevant check.
